#include "students.h"
#include <iostream>
#include <stdlib.h>
#include <string.h>

using namespace std;

void AddStudent(int* numberOfStudents, char*** nameList, char*** surnamesList, int** semesterList, char* imie, char* imie2, char* nazwisko, int semestr)
{
	*numberOfStudents+=1;
	
	char* nameToAdd = malloc(30 * sizeof(char));
	strcpy(nameToAdd, imie);
	strcat(nameToAdd, " ");
	strcat(nameToAdd, imie2);

	char* surnameToAdd = malloc(30 * sizeof(char));
	strcpy(surnameToAdd, nazwisko);

	AddCharList(numberOfStudents, &nameList, nameToAdd);
	AddCharList(numberOfStudents, &surnamesList, surnameToAdd);
	AddIntList(numberOfStudents, &semesterList, semestr);

}

void AddCharList(int numberOfStudents, char*** listChar, char* wyraz)
{
	
}

void AddIntList(int numberOfStudents, int** listInt, int numer)
{
	
}

void PrintListContent (int numberOfStudents, char** charList)
{
	int i;
	for(i=0; i<numberOfStudents; i++)
	{
		cout << **(charList+i) << endl; 
	}
}

void PrintListContent (int numberOfStudents, int* semesterList)
{
	int i;
	for(i=0; i<numberOfStudents; i++)
	{
		cout << *(semesterList+i) << endl; 
	}
}

void PrintListContent (int numberOfStudents, char** namesList, char** surnamesList, int* semesterList)
{
	int i;
	for(i=0; i<numberOfStudents; i++)
	{
		cout << **(surnamesList+i) << ", " << **(namesList+i) << " - semestr " << *(semesterList+i) << endl; 
	}
}

void ClearStudents (int* numberOfStudents, char*** namesList, char*** surnamesList, int** semesterList)
{
	
}
