#pragma once

void AddStudent(int*, char***, char***, int**, char*, char*, char*, int);
void AddCharList(int, char***, char*);
void AddIntList(int, int**, int);
void PrintListContent (int, char**);
void PrintListContent (int, int*);
void PrintListContent (int, char**, char**, int*);
void ClearStudents (int*, char***, char***, int**);
